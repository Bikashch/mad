# TodoAppMAD
First Commit


###TITLE###
ToDo-List

###DESCRIPTION###
TodoAppMAD list is a simple web application to save the so the daily activities of user will not to miss anything.

###Features###
--> Mention the TODO Title
--> Set the task priority
--> Add the saved details
--> Delete single task
--> Delete all tasks

###Technologies used###
--> JAVA
--> MVVM
